<!-- ini slide jumbotron -->
<div class="container">
<section id="mainCarousel">
	<div class="displayStyle">
	<div id="clients" class="carousel slide">
		  <ol class="carousel-indicators">
			<li data-target="#clients" data-slide-to="0" class="active"></li>
			<li data-target="#clients" data-slide-to="1"></li>
			<li data-target="#clients" data-slide-to="2"></li>
            <li data-target="#clients" data-slide-to="3"></li>
		  </ol>
			<div class="carousel-inner">
			<div class="item active">
				<div class="row">
					<div class="span12">
						<img src="<?= base_url('img/tanah.jpg') ?>" alt="#" />
					</div>

				</div>
			</div>
			  <div class="item">
				  <div class="row">
						<div class="span12">
							<img src="<?= base_url('img/air.jpg') ?>" alt="#" />
						</div>
				  </div>
			  </div>
   			<div class="item">
			   <div class="row">
			   <div class="span12">
					<img src="<?= base_url('img/udara.jpg') ?>" alt="#" />
				</div>
				</div>
			  </div>
			</div>
		<a class="left carousel-control" href="#clients" data-slide="prev"></a>
		<a class="right carousel-control" href="#clients" data-slide="next"></a>
	</div>
	</div>
</section>
