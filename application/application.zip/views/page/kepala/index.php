<div class="container">
	<h3 class="title"><span>Portal Kepala Yayasan</span></h3>
	<div class="well">
		<p align="center">
			Selamat Datang di Portal Kepala Yayasan Silahkan Pilih Apa yang akan Anda Lakukan
		</p>
	</div>
	<!-- <div class="row well">
		<div class="col-md-12">
			<h3 class="title"><span>Detail Pemesanan ART Yayasan</span></h3>
			<div id="gp">
				
			</div>
			<script>
      			Morris.Bar({
				  element: 'gp',
				  data: [
				    { y: '2006', a: 100 },
				    { y: '2007', a: 75},
				    { y: '2008', a: 50},
				    { y: '2009', a: 75},
				    { y: '2010', a: 50,},
				    { y: '2011', a: 75},
				    { y: '2012', a: 100}
				  ],
				  xkey: 'y',
				  ykeys: ['a'],
				  labels: ['Series A']
				});	
      		</script>
		</div>	
	</div> -->
</div>

  </body>
</html>