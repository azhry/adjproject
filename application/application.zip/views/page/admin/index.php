
<div class="container">
	<h3 class="title"><span>Portal Admin</span></h3>
	<div class="well">
		<p align="center">
			Selamat Datang di Portal Admin Silahkan Pilih Apa yang akan Anda Lakukan
		</p>
	</div>
</div>

  </body>
</html>