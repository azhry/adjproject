<h3 class="title"><span>Chat Dengan Admin</span></h3>

<div class="container">
	<div class="row">
		<div class="col-md-4 well">
		<h3 class="title"><span>List Chat</span></h3>
			<ul class="nav nav-list">
				<li><a href="#">Nama</a></li>
				<li><a href="#" >Nama</a></li>
				<li><a href="#" >Nama</a></li>
				<li><a href="#" >Nama</a></li>
				
			</ul>
		</div>
		<div class="col-md-6">
			<h3 class="title"><span>Nama Chat</span></h3>
			<div class="col-md-3 pull-right well">
				isi chat
			</div>
			<div class="col-md-3 pull-left well">
				isi chat
			</div>
			<div class="col-md-6">
				<form>
	                <div class="form-group">
	                    <textarea name="chat" id="chat" class="controls" style="width: 100%;" rows="4"></textarea>
	                </div>
	                <input type="submit" class="btn btn-success pull-right" value="Kirim" />    
            	</form>
			</div>
		</div>
	</div>	
</div>